package ejercicio10;

import lectura.Leer;

public class Principal {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int factorial=0;
		
		System.out.println("Indica cualquier número");
		
		for(int x=Leer.datoInt(); x>=factorial; x++) {
			System.out.println(x);
		}

	}

}
