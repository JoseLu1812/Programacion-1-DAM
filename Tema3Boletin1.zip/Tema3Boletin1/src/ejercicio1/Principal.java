package ejercicio1;

public class Principal {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		double result;
		Circulo c=new Circulo (2.3);
		
		result=c.calcularArea();
		System.out.println("El área del círculo es: "+result);

	}

}
