package ejercicio2;

public class Operaciones {
	
	private int num;
	
	//Constructor
	public Operaciones (int num) {
		this.num=num;
	}
	
	//Getters an setters
	public double getNum () {
		return num;
	}
	
	public void setNum (int num) {
		this.num=num;
	}
	
	//Nuestros métodos


}
