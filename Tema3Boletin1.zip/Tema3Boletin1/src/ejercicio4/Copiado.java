package ejercicio4;

public class Copiado {
	
	private String texto;
	
	//Contructor
	
	public Copiado (String texto) {
		this.texto=texto;
	}
	
	//getters and setters
	
	public String getTexto() {
		return texto;
	}
	public void setTexto(String texto) {
		this.texto=texto;
	}
	
	//Nuestros métodos


}
